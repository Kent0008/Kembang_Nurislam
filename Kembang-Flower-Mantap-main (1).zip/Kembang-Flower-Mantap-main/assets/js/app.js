$(function () {

    $('.goods__sorting').on('click', function () {
        $(this).toggleClass('active')
    })


});